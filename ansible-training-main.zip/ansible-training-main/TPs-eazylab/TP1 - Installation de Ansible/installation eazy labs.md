* Se connecter à la plateforme de labs **http://docker.labs.eazytraining.fr/**

* Pour ajouter un **master Ansible** choisir l'image et cliquez sur le boutton Add New Instance

* Pour ajouter un **client  Ansible** choisir l'image et cliquez sur le boutton Add New Instance

* Passer en utilisateur **admin** avec la commande 
```bash
  sudo su admin -
```

* Le mot de passe pour se connecter en ssh avec l'utlisateur **admin** d'un noeud à l'autre est **admin**