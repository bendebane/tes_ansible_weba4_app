Ansible Role : basic apache container
=========

Requirements
------------

No requirements

Role Variables
--------------

This role comes with following variables defined in defaults/main.yml:

```
system_user: test
webapp_port: 80
apache_port: 80
file_template: index.html.j2
ansible_python_interpreter: /usr/bin/python3
```

Dependencies
------------

No dependencies

License
-------

GPLv3