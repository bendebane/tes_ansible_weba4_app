
L'instruction -o StrictHostKeyChecking=no est utilisée pour désactiver 
la vérification stricte de l'hôte lors de l'établissement d'une connexion SSH. 
Cela signifie que l'utilisateur n'est pas averti si la clé SSH de l'hôte est 
inconnue et la connexion est établie 

Le module ping Essaie de se connecter à l'hôte, vérifie une version python 
utilisable et renvoie pong en cas de succès. Pour l'utiliser, il suffit 
d'inclure le module ping dans votre commande ad hoc pour l'exécuter 
sur les hôtes cibles.