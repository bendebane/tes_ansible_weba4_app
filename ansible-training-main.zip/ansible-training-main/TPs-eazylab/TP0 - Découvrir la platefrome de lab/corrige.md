Si vous comptez utiliser l'environement de Lab alors pour avoir les informations suivantes: 
* Accès
* Labs
* Durée d’une session
* Données sensibles
* Agrandir la fenêtre du terminal
* Connexion ssh
* Installation de paquet
* Ouverture de port

alors [voici](https://eazytraining.fr/cours/ansible-pour-devops/lessons/tp-0-presentation-de-la-plateforme-de-tp-by-eazytraining/) le tutoriel à suivre.


