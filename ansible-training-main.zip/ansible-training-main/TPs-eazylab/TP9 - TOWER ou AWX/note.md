### Objectif du TP
Il est question de déployer Tower et refaire le TP5
- Lancer un client et une image franela/dind sur le labs eazytrainning
- Cloner le repos https://github.com/diranetafen/cursus-devops.git et se deplacer a l'intérieur
- Aller dans le dossier tower et desarchiver l'archive contenue dans le répertoire personnel: 
  ```tar -xzcf archive.tar.gz -C ~/```
- Lancer le docker compose
- Se connecter à l'IHM via le port 80
  login: admin 
  password: password
- mot de passe vault du repos pour le déploiement via tower
