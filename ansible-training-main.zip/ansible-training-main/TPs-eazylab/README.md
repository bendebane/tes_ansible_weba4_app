### Ansible pour DevOps
Ce dépôt git est mis en place dans le cadre du suivi du cour ansible pour DevOps.

[Voici](https://eazytraining.fr/cours/ansible-pour-devops/) le lien vers le cours en question.